define( function ( require ) {

	"use strict";

	return {
		app_slug : 'pml-app',
		wp_ws_url : 'https://project-music.live/wp-appkit-api/pml-app',
		wp_url : 'https://project-music.live',
		theme : 'q-android',
		version : '1',
		app_type : 'phonegap-build',
		app_title : 'PML APP',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 2,
		debug_mode : 'off',
		auth_key : 'te%/[P{pR%;NAh~.H!Qe:e$;SubsMu.9e8}+.QYc_CT![;j&|v]9Z1?5x`$7`B/?',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
